
1. Go to https://github.com/new and create a new repo called CensusAnalyzer_USA.
2. Make it public and check 'Add README'.
3. Clone the repo or upload files manually:
   - README.md
   - census_data.csv
   - analysis.ipynb
4. Add a cover message to README like:
   'Built for regional data analysis on CensusAnalyzer USA'
5. Pin this project on your profile.
